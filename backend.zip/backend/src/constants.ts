export const JWT_SECRET = 'SomeRandomSecret';

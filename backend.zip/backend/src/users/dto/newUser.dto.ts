export interface NewUserDTO {
  username: string;
  password: string;
}

export interface UserSignupResponse {
    username: string;
    // can pass an user id here if needed
}

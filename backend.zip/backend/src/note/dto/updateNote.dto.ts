export interface UpdateNoteDto {
  title?: string;
  content?: string;
  tags?: string[];
}

import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Note } from './note.model';
import { NewNoteDto } from './dto/newNote.dto';
import { UpdateNoteDto } from './dto/updateNote.dto';

@Injectable()
export class NoteService {
  constructor(
    @InjectModel(Note)
    private noteModel: typeof Note,
  ) {}

  async create(username: string, newNoteDto: NewNoteDto) {
    // Extract tags from the newNoteDto
    const { tags, ...noteData } = newNoteDto;

    // Create the note
    const note = await this.noteModel.create({
      ...noteData,
      username,
    });

    // Associate tags with the note
    if (tags && tags.length > 0) {
      await note.$set('tags', tags);
    }

    return note;
  }

  async fetchAllForUser(username: string) {
    return this.noteModel.findAll({
      where: {
        username,
      },
      include: 'tags', // Include tags in the result
    });
  }

  async delete(id: string | number) {
    await this.noteModel.destroy({ where: { id } });
  }

  async update(dto: UpdateNoteDto, id: string | number) {
    await this.noteModel.update(dto, { where: { id } });
    return this.noteModel.findByPk(id);
  }
}
